# Changelog
All notable changes to this project will be documented in this file.

## [[1.0.2](https://github.com/acestojanoski/ace-palenight/releases/tag/v1.0.2)] - 2020-05-24
### Changed
- Readme file

## [[1.0.1](https://github.com/acestojanoski/ace-palenight/releases/tag/v1.0.1)] - 2020-05-24
### Changed
- Fix `package.json` repository URL

## [[1.0.0](https://github.com/acestojanoski/ace-palenight/releases/tag/v1.0.0)] - 2020-05-24
Initial release.
